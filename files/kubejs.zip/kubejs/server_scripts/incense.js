ItemEvents.rightClicked("kubejs:shinyincense", event => {
	let player = event.player
    if (player.hasEffect("kubejs:ubershinyboost") || player.hasEffect("kubejs:strongshinyboost"))
        {
            event.server.runCommand(`execute as ${player.username} run yacb remove ${player.username} shiny`)
            player.removeEffect('kubejs:ubershinyboost');
            player.removeEffect('kubejs:strongshinyboost');
        }   
    let duration = 0;
    if (player.hasEffect("kubejs:shinyboost"))
        {
            duration = 16000 + event.player.potionEffects.getDuration("kubejs:shinyboost")
        }
    else 
        {
            duration = 16000;
        }
    player.potionEffects.add("kubejs:shinyboost", duration, 0, true, true);
    event.server.runCommand(`execute as ${player.username} run yacb boost ${player.username} 4 16000 shiny`)
    event.item.count--
})

ItemEvents.rightClicked("kubejs:strongshinyincense", event => {
	let player = event.player
    if (player.hasEffect("kubejs:ubershinyboost") || player.hasEffect("kubejs:shinyboost"))
        {
            event.server.runCommand(`execute as ${player.username} run yacb remove ${player.username} shiny`)
            player.removeEffect('kubejs:ubershinyboost');
            player.removeEffect('kubejs:shinyboost');
        }     
    let duration = 0;
    if (player.hasEffect("kubejs:strongshinyboost"))
        {
            duration = 16000 + event.player.potionEffects.getDuration("kubejs:strongshinyboost")         
        }
    else 
        {
            duration = 16000;
        }
    player.potionEffects.add("kubejs:strongshinyboost", duration, 0, true, true);
    event.server.runCommand(`execute as ${player.username} run yacb boost ${player.username} 8 16000 shiny`)
    event.item.count--
})


ItemEvents.rightClicked("kubejs:ubershinyincense", event => {
	let player = event.player
    if (player.hasEffect('kubejs:shinyboost') || player.hasEffect('kubejs:strongshinyboost'))
        {
            event.server.runCommand(`execute as ${player.username} run yacb remove ${player.username} shiny`)
            player.removeEffect('kubejs:shinyboost');
            player.removeEffect('kubejs:strongshinyboost');
        }
    let duration = 0;
    if (player.hasEffect("kubejs:ubershinyboost"))
        {
            duration = 16000 + event.player.potionEffects.getDuration("kubejs:ubershinyboost")
        }
    else 
        {
            duration = 16000;
        }
    player.potionEffects.add("kubejs:ubershinyboost", duration, 0, true, true);
    event.server.runCommand(`execute as ${player.username} run yacb boost ${player.username} 12 16000 shiny`)
    event.item.count--
    
})
