ServerEvents.recipes(event => {
    event.shapeless('kubejs:fighting_plate', [
        'cobblemon:fighting_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:electric_plate', [
        'cobblemon:electric_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:fire_plate', [
        'cobblemon:fire_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:dragon_plate', [
        'cobblemon:dragon_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:dark_plate', [
        'cobblemon:dark_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:grass_plate', [
        'cobblemon:grass_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:ice_plate', [
        'cobblemon:ice_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:poison_plate', [
        'cobblemon:poison_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:flying_plate', [
        'cobblemon:flying_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:fairy_plate', [
        'cobblemon:fairy_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:ghost_plate', [
        'cobblemon:ghost_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:ground_plate', [
        'cobblemon:ground_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:psychic_plate', [
        'cobblemon:psychic_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:rock_plate', [
        'cobblemon:rock_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:water_plate', [
        'cobblemon:water_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:steel_plate', [
        'cobblemon:steel_gem',
        'minecraft:iron_ingot',
    ])
    event.shapeless('kubejs:bug_plate', [
        'cobblemon:bug_gem',
        'minecraft:iron_ingot',
    ])
});
