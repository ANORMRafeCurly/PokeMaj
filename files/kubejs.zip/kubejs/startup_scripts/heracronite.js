StartupEvents.registry('item', event => { 
    event.create('heracronite').displayName('Heracronite').texture('items:item/mega/heracronite').unstackable()
  })