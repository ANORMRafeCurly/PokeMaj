StartupEvents.registry('item', event => { 
    event.create('salamencite').displayName('Salamencite').texture('items:item/mega/salamencite').unstackable()
  })