StartupEvents.registry('item', event => { 
    event.create('medichamite').displayName('Medichamite').texture('items:item/mega/medichamite').unstackable()
  })