StartupEvents.registry('item', event => { 
    event.create('badgepsy').displayName('Badge Psy').texture('items:item/badgepsy').unstackable()
  })