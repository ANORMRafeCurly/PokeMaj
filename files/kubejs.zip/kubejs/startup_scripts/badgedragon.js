StartupEvents.registry('item', event => { 
    event.create('badgedragon').displayName('Badge Dragon').texture('items:item/badgedragon').unstackable()
  })