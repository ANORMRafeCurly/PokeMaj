StartupEvents.registry('item', event => { 
    event.create('fairy_plate').displayName('Fairy Plate').texture('items:item/plate/fairy_plate').unstackable()
})
