StartupEvents.registry('item', event => { 
    event.create('dark_plate').displayName('Dark Plate').texture('items:item/plate/dark_plate').unstackable()
})
