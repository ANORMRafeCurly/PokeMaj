StartupEvents.registry('item', event => { 
    event.create('absolite').displayName('Absolite').texture('items:item/mega/absolite').unstackable()
  })