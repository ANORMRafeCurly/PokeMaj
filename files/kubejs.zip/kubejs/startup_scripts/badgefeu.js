StartupEvents.registry('item', event => { 
    event.create('badgefeu').displayName('Badge Feu').texture('items:item/badgefeu').unstackable()
  })