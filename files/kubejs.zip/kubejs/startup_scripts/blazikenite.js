StartupEvents.registry('item', event => { 
    event.create('blazikenite').displayName('Blazikenite').texture('items:item/mega/blazikenite').unstackable()
  })