StartupEvents.registry('item', event => { 
    event.create('badgespectre').displayName('Badge Spectre').texture('items:item/badgespectre').unstackable()
  })