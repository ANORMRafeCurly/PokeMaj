StartupEvents.registry('item', event => { 
    event.create('badgeglace').displayName('Badge Glace').texture('items:item/badgeglace').unstackable()
  })