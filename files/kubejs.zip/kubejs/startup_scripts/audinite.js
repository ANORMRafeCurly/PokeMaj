StartupEvents.registry('item', event => { 
    event.create('audinite').displayName('Audinite').texture('items:item/mega/audinite').unstackable()
  })