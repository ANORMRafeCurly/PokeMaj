StartupEvents.registry('item', event => { 
    event.create('grass_plate').displayName('Grass Plate').texture('items:item/plate/grass_plate').unstackable()
})
