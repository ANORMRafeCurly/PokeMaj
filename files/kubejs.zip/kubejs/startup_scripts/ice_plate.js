StartupEvents.registry('item', event => { 
    event.create('ice_plate').displayName('Ice Plate').texture('items:item/plate/ice_plate').unstackable()
})
