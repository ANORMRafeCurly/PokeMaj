StartupEvents.registry('item', event => { 
    event.create('ghost_plate').displayName('Ghost Plate').texture('items:item/plate/ghost_plate').unstackable()
})
