StartupEvents.registry('item', event => { 
    event.create('badgeinsecte').displayName('Badge Insecte').texture('items:item/badgeinsecte').unstackable()
  })