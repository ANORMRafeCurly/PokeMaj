StartupEvents.registry('item', event => { 
    event.create('altarianite').displayName('Altarianite').texture('items:item/mega/altarianite').unstackable()
  })