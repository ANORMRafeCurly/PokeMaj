StartupEvents.registry('item', event => { 
    event.create('flying_plate').displayName('Flying Plate').texture('items:item/plate/flying_plate').unstackable()
})
