StartupEvents.registry('item', event => { 
    event.create('swampertite').displayName('Swampertite').texture('items:item/mega/swampertite').unstackable()
  })