StartupEvents.registry('item', event => { 
    event.create('bug_plate').displayName('Bug Plate').texture('items:item/plate/bug_plate').unstackable()
})
