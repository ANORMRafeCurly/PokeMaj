StartupEvents.registry('item', event => { 
    event.create('psychic_plate').displayName('Psychic Plate').texture('items:item/plate/psychic_plate').unstackable()
})
