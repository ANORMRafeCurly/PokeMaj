StartupEvents.registry('item', event => { 
    event.create('badgeplante').displayName('Badge Plante').texture('items:item/badgeplante').unstackable()
  })