StartupEvents.registry('item', event => { 
    event.create('fire_plate').displayName('Fire Plate').texture('items:item/plate/fire_plate').unstackable()
})
