StartupEvents.registry('item', event => { 
    event.create('lucarionite').displayName('Lucarionite').texture('items:item/mega/lucarionite').unstackable()
  })