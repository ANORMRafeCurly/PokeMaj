StartupEvents.registry('item', event => { 
    event.create('badgefee').displayName('Badge Fee').texture('items:item/badgefee').unstackable()
  })