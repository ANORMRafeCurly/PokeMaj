StartupEvents.registry('item', event => { 
    event.create('badgeelectrik').displayName('Badge Electrik').texture('items:item/badgeelectrik').unstackable()
  })