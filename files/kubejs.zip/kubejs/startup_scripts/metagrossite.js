StartupEvents.registry('item', event => { 
    event.create('metagrossite').displayName('Metagrossite').texture('items:item/mega/metagrossite').unstackable()
  })