StartupEvents.registry('item', event => { 
    event.create('rock_plate').displayName('Rock Plate').texture('items:item/plate/rock_plate').unstackable()
})