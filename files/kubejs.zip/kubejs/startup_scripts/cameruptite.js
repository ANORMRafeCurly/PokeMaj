StartupEvents.registry('item', event => { 
    event.create('cameruptite').displayName('Cameruptite').texture('items:item/mega/cameruptite').unstackable()
  })