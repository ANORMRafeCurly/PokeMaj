StartupEvents.registry('item', event => { 
    event.create('ground_plate').displayName('Ground Plate').texture('items:item/plate/ground_plate').unstackable()
})
