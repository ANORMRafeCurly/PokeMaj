StartupEvents.registry('item', event => { 
    event.create('badgeacier').displayName('Badge Acier').texture('items:item/badgeacier').unstackable()
  })