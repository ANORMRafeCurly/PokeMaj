StartupEvents.registry('item', event => { 
    event.create('manectite').displayName('Manectite').texture('items:item/mega/manectite').unstackable()
  })