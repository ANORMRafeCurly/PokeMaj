StartupEvents.registry('item', event => { 
    event.create('badgesol').displayName('Badge Sol').texture('items:item/badgesol').unstackable()
  })