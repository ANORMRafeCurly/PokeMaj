StartupEvents.registry('item', event => { 
    event.create('houndoominite').displayName('Houndoominite').texture('items:item/mega/houndoominite').unstackable()
  })