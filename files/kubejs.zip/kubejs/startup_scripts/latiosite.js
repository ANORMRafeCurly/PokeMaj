StartupEvents.registry('item', event => { 
    event.create('latiosite').displayName('Latiosite').texture('items:item/mega/latiosite').unstackable()
  })