StartupEvents.registry('item', event => { 
    event.create('aggronite').displayName('Aggronite').texture('items:item/mega/aggronite').unstackable()
  })