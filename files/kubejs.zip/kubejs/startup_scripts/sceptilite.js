StartupEvents.registry('item', event => { 
    event.create('sceptilite').displayName('Sceptilite').texture('items:item/mega/sceptilite').unstackable()
  })