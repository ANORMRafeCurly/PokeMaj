StartupEvents.registry('item', event => { 
    event.create('badgecombat').displayName('Badge Combat').texture('items:item/badgecombat').unstackable()
  })