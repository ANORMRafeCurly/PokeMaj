StartupEvents.registry('item', event => { 
    event.create('diancite').displayName('Diancite').texture('items:item/mega/diancite').unstackable()
  })