StartupEvents.registry('item', event => { 
    event.create('badgevol').displayName('Badge Vol').texture('items:item/badgevol').unstackable()
  })