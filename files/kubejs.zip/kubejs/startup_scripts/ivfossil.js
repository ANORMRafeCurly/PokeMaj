StartupEvents.registry('item', e => {
  e.create('maxivfossil').displayName('Max IV fossil').texture('items:item/maxivfossil').unstackable()
})

