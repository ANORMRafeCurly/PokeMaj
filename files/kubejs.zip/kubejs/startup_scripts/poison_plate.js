StartupEvents.registry('item', event => { 
    event.create('poison_plate').displayName('Poison Plate').texture('items:item/plate/poison_plate').unstackable()
})
