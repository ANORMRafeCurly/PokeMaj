StartupEvents.registry('item', event => { 
    event.create('fighting_plate').displayName('Fighting Plate').texture('items:item/plate/fighting_plate').unstackable()
})
