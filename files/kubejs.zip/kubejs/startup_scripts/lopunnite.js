StartupEvents.registry('item', event => { 
    event.create('lopunnite').displayName('Lopunnite').texture('items:item/mega/lopunnite').unstackable()
  })