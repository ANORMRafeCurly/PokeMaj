StartupEvents.registry('item', event => { 
    event.create('badgetenebres').displayName('Badge Tenebre').texture('items:item/badgetenebres').unstackable()
  })