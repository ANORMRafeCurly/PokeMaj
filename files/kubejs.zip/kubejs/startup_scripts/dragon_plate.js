StartupEvents.registry('item', event => { 
    event.create('dragon_plate').displayName('Dragon Plate').texture('items:item/plate/dragon_plate').unstackable()
})
