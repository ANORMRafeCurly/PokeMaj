StartupEvents.registry('item', event => { 
    event.create('badgevague').displayName('Badge Vague').texture('items:item/badgevague').unstackable()
  })