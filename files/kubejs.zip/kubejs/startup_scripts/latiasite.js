StartupEvents.registry('item', event => { 
    event.create('latiasite').displayName('Latiasite').texture('items:item/mega/latiasite').unstackable()
  })