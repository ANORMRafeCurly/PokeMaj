StartupEvents.registry('item', event => { 
    event.create('badgenormal').displayName('Badge Normal').texture('items:item/badgenormal').unstackable()
  })