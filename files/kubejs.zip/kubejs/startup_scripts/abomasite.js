StartupEvents.registry('item', event => { 
    event.create('abomasite').displayName('Abomasite').texture('items:item/mega/abomasite').unstackable()
  })