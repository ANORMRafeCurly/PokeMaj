StartupEvents.registry('item', event => { 
    event.create('electric_plate').displayName('Electric Plate').texture('items:item/plate/electric_plate').unstackable()
})
