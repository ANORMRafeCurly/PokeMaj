StartupEvents.registry('item', event => { 
    event.create('water_plate').displayName('Water Plate').texture('items:item/plate/water_plate').unstackable()
})
