StartupEvents.registry('mob_effect', event => {
  event.create("shinyboost")
    .beneficial()
    .displayName ("Shiny Luck")
});

StartupEvents.registry('mob_effect', event => {
  event.create("strongshinyboost")
    .beneficial()
    .displayName ("Shiny Luck II")
});

StartupEvents.registry('mob_effect', event => {
  event.create("ubershinyboost")
    .beneficial()
    .displayName ("Shiny Luck III")
});