StartupEvents.registry('item', event => { 
    event.create('badgeeau').displayName('Badge Eau').texture('items:item/badgeeau').unstackable()
  })