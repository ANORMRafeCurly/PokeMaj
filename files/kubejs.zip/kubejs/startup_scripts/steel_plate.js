StartupEvents.registry('item', event => { 
    event.create('steel_plate').displayName('Steel Plate').texture('items:item/plate/steel_plate').unstackable()
})
