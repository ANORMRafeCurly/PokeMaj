StartupEvents.registry('item', event => { 
    event.create('badgepoison').displayName('Badge Poison').texture('items:item/badgepoison').unstackable()
  })