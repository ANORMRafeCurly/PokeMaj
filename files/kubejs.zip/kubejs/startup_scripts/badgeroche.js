StartupEvents.registry('item', event => { 
    event.create('badgeroche').displayName('Badge Roche').texture('items:item/badgeroche').unstackable()
  })